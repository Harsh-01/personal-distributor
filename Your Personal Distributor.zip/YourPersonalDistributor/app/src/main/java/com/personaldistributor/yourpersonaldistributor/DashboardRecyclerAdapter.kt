package com.personaldistributor.yourpersonaldistributor

import android.content.Context
import android.content.Intent
import android.net.Uri
import android.view.LayoutInflater
import android.view.View
import android.view.View.inflate
import android.view.ViewGroup
import android.widget.*
import androidx.appcompat.app.AlertDialog
import androidx.core.content.ContextCompat.startActivity
import androidx.core.content.res.ColorStateListInflaterCompat.inflate
import androidx.fragment.app.FragmentManager
import androidx.recyclerview.widget.RecyclerView
import com.personaldistributor.yourpersonaldistributor.models.Book

import com.squareup.picasso.Picasso
import java.util.logging.Handler
import java.util.zip.Inflater

class DashboardRecyclerAdapter(val context: Context, val itemList:ArrayList<Book> ) : RecyclerView.Adapter<DashboardRecyclerAdapter.Dashboardviewholder>() {

//    lateinit var email:String
//    lateinit var subject:String
//    lateinit var body:String
//    lateinit var chooserTitle :String

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): Dashboardviewholder {
        val view = LayoutInflater.from(parent.context).inflate(R.layout.recycler_dashboard_single_row2,parent, false)
        return Dashboardviewholder(view)
    }

    override fun getItemCount(): Int {
        return itemList.size
    }

    override fun onBindViewHolder(holder: Dashboardviewholder, position: Int) {

        val product = itemList[position]
        holder.productName.text= product.productName
        holder.productCompany.text= product.productCompany
//        holder.productPrice.text= product.productPrice
//        holder.productRating.text= product.productRating
        holder.productImage.setImageResource(product.productImage)
    }

    inner class Dashboardviewholder(view: View): RecyclerView.ViewHolder(view){
        val productName: TextView = view.findViewById(R.id.productName)
        val productCompany: TextView = view.findViewById(R.id.productCompany)
//        val productPrice:TextView = view.findViewById(R.id.productPrice)
//        val productRating:TextView = view.findViewById(R.id.productRating)
        val productImage:ImageView = view.findViewById(R.id.productImage)
        val tick:ImageView = view.findViewById(R.id.tick)
        val pImage = view.findViewById<LinearLayout>(R.id.pImage)

        init {
            if(context is VendorLogin) {
                view.setOnClickListener { v: View ->
                    val position: Int = adapterPosition
                    val builder = AlertDialog.Builder(context)

                    val dialogLayout =
                        LayoutInflater.from(context).inflate(R.layout.edit_text_layout2, null)
                    val units = dialogLayout.findViewById<EditText>(R.id.units)
                    val location = dialogLayout.findViewById<EditText>(R.id.location)


                    with(builder) {
                        setTitle("Interested for ${itemList[position].productName}")
                        setPositiveButton("Send Enquiry") { dialog, which ->
                            Toast.makeText(
                                view.context,
                                "Enquiry sent to ${itemList[position].productCompany} \n Please wait for approval",
                                Toast.LENGTH_LONG
                            ).show()
                            tick.visibility = View.VISIBLE

                        }
                        setNeutralButton("Cancel"){dialog, which ->

                        }
                        setView(dialogLayout)
                        show()

                    }

//                Toast.makeText(view.context, "Interested for ${itemList[position].productName} \n Enquiry sent to ${itemList[position].productCompany} \n Please wait for approval",Toast.LENGTH_LONG).show()
                }
                productImage.setOnClickListener {
                    Toast.makeText(
                        view.context,
                        " 180 degree flip with MRP, Margin, Units",
                        Toast.LENGTH_LONG
                    ).show()
                }
            }
            else if(context is AgentLogin){
                view.setOnClickListener { v: View ->
                    val position: Int = adapterPosition
                    val builder = AlertDialog.Builder(context)

                    val dialogLayout =
                        LayoutInflater.from(context).inflate(R.layout.edit_text_layout3, null)
                    val unitsA = dialogLayout.findViewById<EditText>(R.id.unitsA)
                    val shops = dialogLayout.findViewById<EditText>(R.id.shops)


                    with(builder) {
                        setTitle("Interested for ${itemList[position].productName}")
                        setPositiveButton("Send Enquiry") { dialog, which ->
                            tick.visibility = View.VISIBLE
                            Toast.makeText(
                                view.context,
                                "Enquiry sent to ${itemList[position].productCompany} \n Please wait for approval",
                                Toast.LENGTH_LONG
                            ).show()

                        }
                        setNeutralButton("Cancel"){dialog, which ->  

                        }
                        setView(dialogLayout)
                        show()

                    }

//                Toast.makeText(view.context, "Interested for ${itemList[position].productName} \n Enquiry sent to ${itemList[position].productCompany} \n Please wait for approval",Toast.LENGTH_LONG).show()
                }
                productImage.setOnLongClickListener() {
//                    Toast.makeText(
//                        view.context,
//                        " 180 degree flip with MRP, Margin, Units",
//                        Toast.LENGTH_LONG
//                    ).show()
                    productImage.animate().apply {
                        duration =2000
                        rotationYBy(360f)
                    }.start()

                    productImage.visibility = View.INVISIBLE
                    pImage.visibility = View.VISIBLE
                    true
                }
                pImage.setOnLongClickListener(){
                    pImage.animate().apply {
                        duration =2000
                        rotationYBy(360f)
                    }.start()
                    productImage.visibility = View.VISIBLE
                    pImage.visibility = View.GONE
                    true
                }
            }
        }

    }
}
