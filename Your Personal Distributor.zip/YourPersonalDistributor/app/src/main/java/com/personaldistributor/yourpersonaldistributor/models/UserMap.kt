package com.personaldistributor.yourpersonaldistributor.models

class UserMap(val title:String, val places:List<Place>){

}