package com.personaldistributor.yourpersonaldistributor.fragments

import android.app.Activity
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.util.Log
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ProgressBar
import android.widget.RelativeLayout
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import androidx.core.app.ActivityCompat
import androidx.recyclerview.widget.GridLayoutManager
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.android.volley.Response
import com.android.volley.toolbox.JsonObjectRequest
import com.android.volley.toolbox.Volley
import com.personaldistributor.yourpersonaldistributor.DashboardRecyclerAdapter

import com.personaldistributor.yourpersonaldistributor.R
import com.personaldistributor.yourpersonaldistributor.models.Book
import com.personaldistributor.yourpersonaldistributor.util.ConnectionManager
import org.json.JSONException
import java.lang.reflect.Method


class HistoryProductFragment : Fragment() {

    lateinit var recyclerDashboard: RecyclerView

    lateinit var layoutManager: RecyclerView.LayoutManager

    lateinit var progressLayout: RelativeLayout

    lateinit var progressbBar: ProgressBar

    lateinit var recyclerAdapter : DashboardRecyclerAdapter


    val bookInfoList = arrayListOf<Book>(
        Book("Samyang","Nestle",R.drawable.koreannoodles),
        Book("Agristar Genuine Oil","Tafe",R.drawable.engineoil),
        Book("Earpods","Boat",R.drawable.earbuds),
        Book("Singfong","Nestle",R.drawable.koreannoodles1),
        Book("Elemis","Breckwell",R.drawable.americanfacewash),
        Book("Shouvy","Jukovik",R.drawable.japanisoap1),
        Book("Doms Pencils","Doms",R.drawable.pencils),
        Book("Dracefu","Idarta",R.drawable.japanisoap),
        Book("Cremia","Creams",R.drawable.japanicream),
        Book("Burger","Nestle",R.drawable.burger),
        Book("Chings","Chingana",R.drawable.japaninoodles)

    )


    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {

        val view =inflater.inflate(R.layout.fragment_history_product, container, false)

        recyclerDashboard = view.findViewById(R.id.recyclerDashboard)
        layoutManager = GridLayoutManager(activity,2)

       // progressLayout = view.findViewById(R.id.progressLayout)

        //progressbBar = view.findViewById(R.id.progressBar)

       // progressLayout.visibility = View.VISIBLE

        recyclerAdapter = DashboardRecyclerAdapter(activity as Context,bookInfoList)
        recyclerDashboard.adapter = recyclerAdapter
        recyclerDashboard.layoutManager = layoutManager

        return view
    }

}