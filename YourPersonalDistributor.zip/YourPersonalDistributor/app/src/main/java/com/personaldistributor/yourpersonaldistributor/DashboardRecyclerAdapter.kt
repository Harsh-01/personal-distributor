package com.personaldistributor.yourpersonaldistributor

import android.content.Context
import android.content.Intent
import android.net.Uri
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import androidx.core.content.ContextCompat.startActivity
import androidx.recyclerview.widget.RecyclerView
import com.personaldistributor.yourpersonaldistributor.models.Book

import com.squareup.picasso.Picasso

class DashboardRecyclerAdapter(val context: Context, val itemList:ArrayList<Book> ) : RecyclerView.Adapter<DashboardRecyclerAdapter.Dashboardviewholder>() {
    lateinit var favourites : ImageView

//    lateinit var email:String
//    lateinit var subject:String
//    lateinit var body:String
//    lateinit var chooserTitle :String

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): Dashboardviewholder {
        val view = LayoutInflater.from(parent.context).inflate(R.layout.recycler_dashboard_single_row,parent, false)



        return Dashboardviewholder(view)
    }

    override fun getItemCount(): Int {
        return itemList.size
    }

    override fun onBindViewHolder(holder: Dashboardviewholder, position: Int) {

        val product = itemList[position]
        holder.productName.text= product.productName
        holder.productCompany.text= product.productCompany
        holder.productPrice.text= product.productPrice
        holder.productRating.text= product.productRating
        holder.productImage.setImageResource(product.productImage)
    }

    class Dashboardviewholder(view: View): RecyclerView.ViewHolder(view){
        val productName: TextView = view.findViewById(R.id.productName)
        val productCompany: TextView = view.findViewById(R.id.productCompany)
        val productPrice:TextView = view.findViewById(R.id.productPrice)
        val productRating:TextView = view.findViewById(R.id.productRating)
        val productImage:ImageView = view.findViewById(R.id.productImage)

    }
}
