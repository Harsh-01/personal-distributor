package com.personaldistributor.yourpersonaldistributor

class Ag_Users{
    var email = ""
    var agent_code = ""
    var setPass = ""
    var username= ""
    var mobile = ""
    var user_age = ""
    var gender = ""
    var address = ""
    var isAgent = false
    var profilepic : String = ""
    var panCard : String = ""
    var aadharCardFront : String = ""
    var aadharCardBack : String = ""
    var contract : String  = ""
    var check : String = ""


    constructor(){

    }


    constructor(email:String,agent_code: String, setPass: String, username: String ,mobile: String, user_age: String, gender: String, address:String,
                isAgent:Boolean, profilepic: String, panCard:String, aadharCardFront:String,
                    aadharCardBack:String, contract:String, check:String) : this(){
        this.email = email
        this.agent_code = agent_code
        this.setPass = setPass
        this.username = username
        this.mobile = mobile
        this.user_age = user_age
        this.gender = gender
        this.address = address
        this.isAgent = isAgent
        this.profilepic = profilepic
        this.panCard = panCard
        this.aadharCardFront = aadharCardFront
        this.aadharCardBack = aadharCardBack
        this.contract = contract
        this.check = check
    }

//    public fun getprofilepic() : String{
//        return profilepic
//    }
//    public fun setprofilepic(photo: String){
//        profilepic = photo
//    }
//    public fun getusername() : String{
//        return username
//    }
//    public fun setusername(name: String){
//        username = name
//    }
//    public fun getaddress() : String{
//        return address
//    }
//    public fun setaddress(address1: String){
//        address = address1
//    }
}
