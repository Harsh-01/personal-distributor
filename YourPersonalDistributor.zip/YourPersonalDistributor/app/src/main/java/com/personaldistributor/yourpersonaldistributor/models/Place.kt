package com.personaldistributor.yourpersonaldistributor.models


class Place(val title:String, val description:String,val latitude:Double, val longitude:Double){

}