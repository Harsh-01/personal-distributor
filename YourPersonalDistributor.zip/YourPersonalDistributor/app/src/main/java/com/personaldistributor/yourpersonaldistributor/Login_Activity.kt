package com.personaldistributor.yourpersonaldistributor

import android.content.Context
import android.content.Intent
import android.content.SharedPreferences
import android.os.Bundle
import android.os.Handler
import android.view.View
import android.widget.*
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.auth.FirebaseUser
import com.google.firebase.auth.ktx.auth
import com.google.firebase.database.DataSnapshot
import com.google.firebase.database.DatabaseError
import com.google.firebase.database.ValueEventListener
import com.google.firebase.database.ktx.database
import com.google.firebase.ktx.Firebase


class Login_Activity : AppCompatActivity() {
    lateinit var etregistered_No: EditText
    lateinit var etpassword: EditText
    lateinit var btnLogin: Button
    val validmobileNumber = "7985170875"
    val validPassword = "adarsh"
    private lateinit var auth: FirebaseAuth
    val database = Firebase.database
    val myRef = database.getReference("Users/Login")
    lateinit var sharedMail : SharedPreferences
    lateinit var sharedState: SharedPreferences

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.login_page)
        title = "Login Profile"
        val register_options = resources.getStringArray((R.array.register_options))
        //access the spinner
        val registerSpinner = findViewById<Spinner>(R.id.spinner3)
        sharedMail = getSharedPreferences(getString(R.string.preference_code), Context.MODE_PRIVATE)
        sharedState = getSharedPreferences(getString(R.string.preference_boolean), Context.MODE_PRIVATE)


// Initialize Firebase Auth
        auth = Firebase.auth
        etregistered_No = findViewById(R.id.etregistered_No)
        etpassword = findViewById(R.id.etpassword)
        btnLogin = findViewById(R.id.btnLogin)
        btnLogin.setOnClickListener {
//            val mobileNo= etregistered_No.text.toString()
//            val password = etpassword.text.toString()

//            if ((mobileNo == validmobileNumber) && (password == validPassword)) {
//                val intent = Intent(this@Login_Activity, AgentLogin::class.java)
//                startActivity(intent)
//            } else {
//                Toast.makeText(
//                    this@Login_Activity,
//                    "Incorrect details",
//                    Toast.LENGTH_SHORT
//                ).show()
//            }
            signInUser()

        }

            if (registerSpinner != null) {
                val adapter =
                    ArrayAdapter(this, android.R.layout.simple_spinner_item, register_options)
                adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)
                registerSpinner.adapter = adapter

                registerSpinner.onItemSelectedListener = object :
                    AdapterView.OnItemSelectedListener {
                    override fun onItemSelected(
                        parent: AdapterView<*>,
                        view: View,
                        position: Int,
                        id: Long
                    ) {

                        if (register_options[position] == "Agent") {
                            Handler().postDelayed({
                                Toast.makeText(
                                    this@Login_Activity,
                                    getString(R.string.selected_item) + " " + " " + register_options[position],
                                    Toast.LENGTH_SHORT
                                ).show()
                            }, 1000)
                            val intent1 = Intent(this@Login_Activity, Agent_register::class.java)
                            startActivity(intent1)

                        } else if (register_options[position] == "Executive") {
                            Handler().postDelayed({
                                Toast.makeText(
                                    this@Login_Activity,
                                    getString(R.string.selected_item) + " " + " " + register_options[position],
                                    Toast.LENGTH_SHORT
                                ).show()
                            }, 1000)
                            //Add Intents
                        } else if (register_options[position] == "Shop Owner") {
                            Handler().postDelayed({
                                Toast.makeText(
                                    this@Login_Activity,
                                    getString(R.string.selected_item) + " " + " " + register_options[position],
                                    Toast.LENGTH_SHORT
                                ).show()
                            }, 1000)
                            val intent1 = Intent(this@Login_Activity, Vendor_register::class.java)
                            startActivity(intent1)
                        }
                    }

                    override fun onNothingSelected(parent: AdapterView<*>?) {
                        Handler().postDelayed({
                            Toast.makeText(
                                this@Login_Activity,
                                "Welcome to Login page",
                                Toast.LENGTH_SHORT
                            ).show()
                        }, 1000)
                    }

                }
            }
//        val imglogo = findViewById<ImageView>(R.id.imglogo)
//        ViewCompat.animate(imglogo)
////            .translationX(50f)
//            .translationY(-400f)
//            .setDuration(1000)
//            .setInterpolator(AccelerateDecelerateInterpolator())
//            .setStartDelay(50)

    }

    private fun signInUser(){
        if(etregistered_No.text.toString().isEmpty()){
            etregistered_No.error = "Please enter email"
            etregistered_No.requestFocus()
            return
        }
        if(etpassword.text.toString().isEmpty()){
            etpassword.error = "Please enter password"
            etpassword.requestFocus()
            return
        }
        auth.signInWithEmailAndPassword(etregistered_No.text.toString(), etpassword.text.toString())
            .addOnCompleteListener(this) { task ->
                if (task.isSuccessful) {
                    val isAgent = sharedState.getBoolean("isAgent", false)
                    val userId = sharedMail.getString("UID", "AICHYUDERTY")
//                    var type = false
//                    val userId = auth.currentUser?.uid
//                    myRef.child(userId.toString()).child("isAgent")
//                        .addValueEventListener(object : ValueEventListener {
//                        override fun onDataChange(dataSnapshot: DataSnapshot) {
//                            // getting a DataSnapshot for the location at the specified
//                            // relative path and getting in the link variable
//                            type= dataSnapshot.getValue(Boolean::class.java) as Boolean
//                        }
//
//                        // this will called when any problem
//                        // occurs in getting data
//                        override fun onCancelled(databaseError: DatabaseError) {
//                            // we are showing that error message in toast
//                            Toast.makeText(
//                                this@Login_Activity,
//                                "Please re-enter login details",
//                                Toast.LENGTH_SHORT
//                            ).show()
//                        }
//                    })
//                    if(type){
//                        val intent = Intent(this@Login_Activity, AgentLogin::class.java)
//                        startActivity(intent)
//                    }else{
//                        val intent = Intent(this@Login_Activity, VendorLogin::class.java)
//                        startActivity(intent)
//                    }
//                    val dialog = AlertDialog.Builder(this@Login_Activity)
//                    dialog.setMessage("CONTINUE AS")
//                     dialog.setPositiveButton("Agent")
//                    {
//                    text, listener ->val intent = Intent(this@Login_Activity, AgentLogin::class.java)
//                        startActivity(intent)
//
//
//                    }
//                    dialog.setNegativeButton("Vendor")
//                    {
//                    text, listener -> val intent = Intent(this@Login_Activity, VendorLogin::class.java)
//                        startActivity(intent)
//
//                    }
//                    dialog.create()
//                    dialog.show()

//                    val intent = Intent(this@Login_Activity, AgentLogin::class.java)
//                    startActivity(intent)
                    val uid = auth.currentUser?.uid
                    myRef.child(uid.toString()).child("ID").setValue(userId)
                    myRef.child(uid.toString()).child("isAgent").setValue(isAgent)

                    if(isAgent){
                        val intent = Intent(this@Login_Activity, AgentLogin::class.java)
                        startActivity(intent)
                    }else{
                        val intent = Intent(this@Login_Activity, VendorLogin::class.java)
                        startActivity(intent)
                    }

                } else {
                    // If sign in fails, display a message to the user.

                    Toast.makeText(baseContext, "Authentication failed.",
                        Toast.LENGTH_SHORT).show()

                }

                // ...
            }
    }

    public override fun onStart() {
        super.onStart()
        // Check if user is signed in (non-null) and update UI accordingly.
        val currentUser = auth.currentUser
        updateUI(currentUser)
    }

    fun updateUI(currentUser : FirebaseUser?){
        if(currentUser != null){
//            Toast.makeText(this, "Signed In Successfully", Toast.LENGTH_SHORT).show()
//            startActivity(Intent(this, AgentLogin::class.java))
        }
    }
}
