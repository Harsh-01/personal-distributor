package com.personaldistributor.yourpersonaldistributor.fragments

import android.content.Context
import android.net.Uri
import android.os.Bundle
import android.os.Handler
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.AdapterView
import android.widget.ArrayAdapter
import android.widget.Toast

import com.personaldistributor.yourpersonaldistributor.R
import android.widget.Spinner as Spinner


class TodayFragment : Fragment() {

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        val view =inflater.inflate(R.layout.fragment_today, container, false)
        // Inflate the layout for this fragment
//        var default_option = resources.getStringArray((R.array.defaultMode))
//        //access the spinner
//        val defSpinner = view?.findViewById<Spinner>(R.id.spinnerA)
//        if (defSpinner != null) {
//            val adapter =
//                ArrayAdapter(activity as Context, android.R.layout.simple_spinner_item, default_option)
//            adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)
//            defSpinner?.adapter = adapter
//
//            defSpinner?.onItemSelectedListener = object :
//                AdapterView.OnItemSelectedListener {
//                override fun onItemSelected(
//                    parent: AdapterView<*>,
//                    view: View,
//                    position: Int,
//                    id: Long
//                ) {
//
//                    if (default_option[position] == "Shop pay") {
//                        Handler().postDelayed({
//                            Toast.makeText(
//                                activity as Context,
//                                getString(R.string.selected_item) + " " + " " + default_option[position],
//                                Toast.LENGTH_SHORT
//                            ).show()
//                        }, 1000)
//
//
//                    } else if (default_option[position] == "Product pay") {
//                        Handler().postDelayed({
//                            Toast.makeText(
//                                activity as Context,
//                                getString(R.string.selected_item) + " " + " " + default_option[position],
//                                Toast.LENGTH_SHORT
//                            ).show()
//
//                        }, 1000)
//                        //Add Intents
//
//                    }else if (default_option[position] == "Deposit pay") {
//                        Handler().postDelayed({
//                            Toast.makeText(
//                                activity as Context,
//                                getString(R.string.selected_item) + " " + " " + default_option[position],
//                                Toast.LENGTH_SHORT
//                            ).show()
//
//                        }, 1000)
//                    }
//                }
//
//                override fun onNothingSelected(parent: AdapterView<*>?) {
//                    Handler().postDelayed({
//                        Toast.makeText(
//                            activity as Context,
//                            "Welcome to Payment Window page",
//                            Toast.LENGTH_SHORT
//                        ).show()
//                    }, 1000)
//                }
//
//            }
//        }

        return view


    }

}