package com.personaldistributor.yourpersonaldistributor.models

class Post (
    var name1 : String,
    var id1 : String,
    var posttext: String
)