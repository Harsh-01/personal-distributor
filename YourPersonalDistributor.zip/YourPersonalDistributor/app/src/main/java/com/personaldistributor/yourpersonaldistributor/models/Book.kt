package com.personaldistributor.yourpersonaldistributor.models

 class Book (
   val productName : String,
   val productCompany : String,
   val productPrice : String,
   val productRating : String,
   val productImage : Int
)




