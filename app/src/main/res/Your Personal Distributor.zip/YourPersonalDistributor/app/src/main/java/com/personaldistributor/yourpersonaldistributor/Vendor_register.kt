package com.personaldistributor.yourpersonaldistributor

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.View
import android.widget.*

class Vendor_register : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.vendor_register_page)

        //Add stage2 button
        val stage2btn : Button = findViewById(R.id.stage2_button)
        var size_type :String
        var influence_type :String
        var shop_type : String
        //access the items of the lists
        val shop_types = resources.getStringArray(R.array.shop_type)
        val shop_sizes = resources.getStringArray(R.array.shop_size)
        val shop_influences = resources.getStringArray((R.array.shop_influence))
        //access the spinner
        val shop_type_spinner = findViewById<Spinner>(R.id.shop_type_spinner)
        val spinner = findViewById<Spinner>(R.id.spinner1)
        val spinner2 = findViewById<Spinner>(R.id.spinner2)
        if(spinner != null){
            val adapter = ArrayAdapter(this, android.R.layout.simple_spinner_item, shop_sizes)
            adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)
            spinner.adapter = adapter

            spinner.onItemSelectedListener = object :
                AdapterView.OnItemSelectedListener{
                    override fun onItemSelected(parent: AdapterView<*>,view: View, position: Int, id : Long){
                        if(position != 0) {
                            Toast.makeText(
                                this@Vendor_register,
                                getString(R.string.selected_item) + " " + " " + shop_sizes[position],
                                Toast.LENGTH_SHORT
                            ).show()
                            size_type = shop_sizes[position]       //Store string
                        }
                    }

                override fun onNothingSelected(parent: AdapterView<*>?) {
                    TODO("not implemented") //To change body of created functions use File | Settings | File Templates.
                }

            }
        }
        if(spinner2 != null){
            val adapter = ArrayAdapter(this, android.R.layout.simple_spinner_item, shop_influences)
            adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)
            spinner2.adapter = adapter

            spinner2.onItemSelectedListener = object :
                AdapterView.OnItemSelectedListener{
                override fun onItemSelected(parent: AdapterView<*>,view: View, position: Int, id : Long){
                    if(position != 0) {
                        Toast.makeText(
                            this@Vendor_register,
                            getString(R.string.selected_item) + " " + " " + shop_influences[position],
                            Toast.LENGTH_SHORT
                        ).show()
                        influence_type = shop_influences[position]      //Store String
                    }
                }

                override fun onNothingSelected(parent: AdapterView<*>?) {
                    TODO("not implemented") //To change body of created functions use File | Settings | File Templates.
                }

            }
        }
        if(shop_type_spinner != null){
            val adapter = ArrayAdapter(this, android.R.layout.simple_spinner_item, shop_types)
            adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)
            spinner.adapter = adapter

            spinner.onItemSelectedListener = object :
                AdapterView.OnItemSelectedListener{
                override fun onItemSelected(parent: AdapterView<*>,view: View, position: Int, id : Long){
                    if(position != 0) {
                        Toast.makeText(
                            this@Vendor_register,
                            getString(R.string.selected_item) + " " + " " + shop_types[position],
                            Toast.LENGTH_SHORT
                        ).show()
                        shop_type = shop_types[position]       //Store string
                    }
                }

                override fun onNothingSelected(parent: AdapterView<*>?) {
                    TODO("not implemented") //To change body of created functions use File | Settings | File Templates.
                }

            }
        }

        //Go to next page
        stage2btn.setOnClickListener {
            val newIntent = Intent(this@Vendor_register, RegisterPage2::class.java)
            startActivity(newIntent)
        }
    }
}
