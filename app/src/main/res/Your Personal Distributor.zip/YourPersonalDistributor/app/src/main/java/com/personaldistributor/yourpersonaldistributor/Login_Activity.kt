package com.personaldistributor.yourpersonaldistributor

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.os.Handler
import android.view.View
import android.widget.*

class Login_Activity : AppCompatActivity() {
    lateinit var etregistered_No: EditText
    lateinit var etpassword: EditText
    lateinit var btnLogin: Button
    val validmobileNumber = "7985170875"
    val validPassword = "adarsh"

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.login_page)
        title = "Login"
        val register_options = resources.getStringArray((R.array.register_options))
        //access the spinner
        val registerSpinner = findViewById<Spinner>(R.id.spinner3)
        etregistered_No = findViewById(R.id.etregistered_No)
        etpassword = findViewById(R.id.etpassword)
        btnLogin = findViewById(R.id.btnLogin)
        btnLogin.setOnClickListener {
            val mobileno = etregistered_No.text.toString()
            val password = etpassword.text.toString()

            if ((mobileno == validmobileNumber) && (password == validPassword)) {
                val intent = Intent(this@Login_Activity, AgentLogin::class.java)
                startActivity(intent)
            } else {
                Toast.makeText(
                    this@Login_Activity,
                    "Incorrect details",
                    Toast.LENGTH_SHORT
                ).show()
            }
        }
            if (registerSpinner != null) {
                val adapter =
                    ArrayAdapter(this, android.R.layout.simple_spinner_item, register_options)
                adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)
                registerSpinner.adapter = adapter

                registerSpinner.onItemSelectedListener = object :
                    AdapterView.OnItemSelectedListener {
                    override fun onItemSelected(
                        parent: AdapterView<*>,
                        view: View,
                        position: Int,
                        id: Long
                    ) {

                        if (register_options[position] == "Agent") {
                            Handler().postDelayed({
                                Toast.makeText(
                                    this@Login_Activity,
                                    getString(R.string.selected_item) + " " + " " + register_options[position],
                                    Toast.LENGTH_SHORT
                                ).show()
                            }, 1000)
                            val intent1 = Intent(this@Login_Activity, Agent_register::class.java)
                            startActivity(intent1)

                        } else if (register_options[position] == "Executive") {
                            Handler().postDelayed({
                                Toast.makeText(
                                    this@Login_Activity,
                                    getString(R.string.selected_item) + " " + " " + register_options[position],
                                    Toast.LENGTH_SHORT
                                ).show()
                            }, 1000)
                            //Add Intents
                        } else if (register_options[position] == "Shop Owner") {
                            Handler().postDelayed({
                                Toast.makeText(
                                    this@Login_Activity,
                                    getString(R.string.selected_item) + " " + " " + register_options[position],
                                    Toast.LENGTH_SHORT
                                ).show()
                            }, 1000)
                            val intent1 = Intent(this@Login_Activity, Vendor_register::class.java)
                            startActivity(intent1)
                        }
                    }

                    override fun onNothingSelected(parent: AdapterView<*>?) {
                        Handler().postDelayed({
                            Toast.makeText(
                                this@Login_Activity,
                                "Welcome to Login page",
                                Toast.LENGTH_SHORT
                            ).show()
                        }, 1000)
                    }

                }
            }
    }
}
