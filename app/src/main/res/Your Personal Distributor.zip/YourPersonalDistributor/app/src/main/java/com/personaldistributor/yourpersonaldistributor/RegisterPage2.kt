package com.personaldistributor.yourpersonaldistributor

import android.annotation.SuppressLint
import android.app.Activity
import android.content.ActivityNotFoundException
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.net.Uri
import android.os.Bundle
import android.os.Environment
import android.provider.MediaStore
import android.widget.Button
import android.widget.ImageView
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import androidx.core.content.FileProvider
import java.io.File
import java.io.IOException
import java.text.SimpleDateFormat
import java.util.*
import java.util.jar.Manifest

class RegisterPage2: AppCompatActivity(){
    private val cameraRequest1 = 18
    private val cameraRequest2 = 28
    private val cameraRequest3 = 38

    lateinit var currentPhotoPath: String

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.register_page2)
        title = "Upload Images"

        val photoButton1 : Button = findViewById(R.id.profile_button)
        val photoButton2 : Button = findViewById(R.id.shop_image_button)
        val photoButton3 : Button = findViewById(R.id.aadhar_button)
        val registerButton : Button = findViewById(R.id.register_button) //Register Button

        photoButton1.setOnClickListener {
            try {
                Intent(MediaStore.ACTION_IMAGE_CAPTURE).also { takePictureIntent ->
                    //Ensure that there's a camera activity to handle the intent
                    takePictureIntent.resolveActivity(packageManager)?.also {
                        //Create the file where the photo should go
                        val photoFile: File? = try {
                            createImageFile()
                        } catch (ex: IOException) {
                            //Error occured while creating the file
                            null
                        }
                        //Continue only if the File was successfully created
                        photoFile?.also {
                            val photoURI: Uri = FileProvider.getUriForFile(
                                this,
                                "com.personaldistributor.yourpersonaldistributor",
                                it
                            )
                            takePictureIntent.putExtra(MediaStore.EXTRA_OUTPUT, photoURI)
                            startActivityForResult(takePictureIntent, cameraRequest1)
                        }
                    }
                }
            }catch (e: ActivityNotFoundException){
                //display error state to the user
            }
        }
        photoButton2.setOnClickListener {
            try {
                Intent(MediaStore.ACTION_IMAGE_CAPTURE).also { takePictureIntent ->
                    //Ensure that there's a camera activity to handle the intent
                    takePictureIntent.resolveActivity(packageManager)?.also {
                        //Create the file where the photo should go
                        val photoFile: File? = try {
                            createImageFile()
                        } catch (ex: IOException) {
                            //Error occured while creating the file
                            null
                        }
                        //Continue only if the File was successfully created
                        photoFile?.also {
                            val photoURI: Uri = FileProvider.getUriForFile(
                                this,
                                "com.personaldistributor.yourpersonaldistributor",
                                it
                            )
                            takePictureIntent.putExtra(MediaStore.EXTRA_OUTPUT, photoURI)
                            startActivityForResult(takePictureIntent, cameraRequest2)
                        }
                    }
                }
            }catch (e: ActivityNotFoundException){
                //display error state to the user
            }

        }
        photoButton3.setOnClickListener {
            try {
                Intent(MediaStore.ACTION_IMAGE_CAPTURE).also { takePictureIntent ->
                    //Ensure that there's a camera activity to handle the intent
                    takePictureIntent.resolveActivity(packageManager)?.also {
                        //Create the file where the photo should go
                        val photoFile: File? = try {
                            createImageFile()
                        } catch (ex: IOException) {
                            //Error occured while creating the file
                            null
                        }
                        //Continue only if the File was successfully created
                        photoFile?.also {
                            val photoURI: Uri = FileProvider.getUriForFile(
                                this,
                                "com.personaldistributor.yourpersonaldistributor",
                                it
                            )
                            takePictureIntent.putExtra(MediaStore.EXTRA_OUTPUT, photoURI)
                            startActivityForResult(takePictureIntent, cameraRequest3)
                        }
                    }
                }
            }catch (e: ActivityNotFoundException){
                //display error state to the user
            }

        }

    }

    //SOME ERROR HERE as intent = null
    @SuppressLint("MissingSuperCall")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        if(requestCode == cameraRequest1 && resultCode == Activity.RESULT_OK){
            galleryAddPic()
//            val imageBitmap = data?.extras?.get("data") as Bitmap
//            imageView1.setImageBitmap(imageBitmap)
        }
        if(requestCode == cameraRequest2 && resultCode == Activity.RESULT_OK){
            galleryAddPic()
//            val imageBitmap = data?.extras?.get("data") as Bitmap
//            imageView2.setImageBitmap(imageBitmap)
        }
        if(requestCode == cameraRequest3 && resultCode == Activity.RESULT_OK){
            galleryAddPic()
//            val imageBitmap = data?.extras?.get("data") as Bitmap
//            imageView3.setImageBitmap(imageBitmap)
        }
    }

    private fun createImageFile(): File {
        //create an image file name
        val timestamp:String = SimpleDateFormat("yyyyMMdd_HHmmss").format(Date())
        val storageDir: File? = getExternalFilesDir(Environment.DIRECTORY_PICTURES)
        return File.createTempFile(
            "IMG_${timestamp}_" ,
            ".jpg",
            storageDir  /*directory*/
        ).apply {
            //Save a file path for use with ACTION_VIEW intents
            currentPhotoPath = absolutePath
        }
    }

    //Add to gallery
    private fun galleryAddPic(){
        Intent(Intent.ACTION_MEDIA_SCANNER_SCAN_FILE).also { mediaScanIntent ->
            val f = File(currentPhotoPath)
            mediaScanIntent.data = Uri.fromFile(f)
            sendBroadcast(mediaScanIntent)
        }
    }

    //Decode a scales image - dont know where to use
//    private fun setPic(imageView: ImageView){
//        //Get the dimensions of the view
//        val targetW: Int = imageView.width
//        val targetH: Int = imageView.height
//
//        val bmOptions = BitmapFactory.Options().apply{
//            //Get the dimensions of the bitmap
//            inJustDecodeBounds = true
//
//            BitmapFactory.decodeFile(currentPhotoPath, this)
//
//            val photoW: Int = outWidth
//            val photoH: Int = outHeight
//            //Determine how much to scale down the image
//            val scaleFactor : Int = Math.max(1, Math.min(photoW/targetW, photoH/targetH))
//
//            //Decode the image file into a Bitmap sized to fill the view
//            inJustDecodeBounds = false
//            inSampleSize = scaleFactor
//            inPurgeable = true
//        }
//        BitmapFactory.decodeFile(currentPhotoPath, bmOptions)?.also{bitmap ->
//            imageView.setImageBitmap(bitmap)
//        }
//    }

}